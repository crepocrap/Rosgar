package com.pixelcutaero.editor;

import android.app.Activity;
import android.content.ContentValues;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.provider.Settings;
import android.util.Base64;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FilterInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.channels.FileChannel;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.json.JSONObject;

public class MainActivity extends Activity {
    private static final String HOST = "appassets.androidplatform.net";
    private static final String BASE_URL = "https://" + HOST;
    private static final int FILE_PICK_REQUEST = 4102;
    private static final int PICK_MEDIA_REQUEST = 4103;
    private String pendingMediaType = "video";
    private String pendingMediaMode = "clip";

    private WebView webView;
    private ValueCallback<Uri[]> fileChooserCallback;
    private final Map<String, Uri> mediaUris = new ConcurrentHashMap<>();
    private final Map<String, String> reverseMediaIds = new ConcurrentHashMap<>();

    private Uri exportUri;
    private OutputStream exportStream;
    private File legacyExportFile;
    private String exportName;
    private final Object exportLock = new Object();

    @Override
    public void onCreate(Bundle state) {
        super.onCreate(state);
        Window w = getWindow();
        w.setStatusBarColor(Color.rgb(6, 34, 63));
        w.setNavigationBarColor(Color.rgb(2, 13, 34));
        if (Build.VERSION.SDK_INT >= 29) {
            w.setNavigationBarContrastEnforced(false);
            w.setStatusBarContrastEnforced(false);
        }

        webView = new WebView(this);
        webView.setBackgroundColor(Color.rgb(2, 13, 34));
        webView.setOverScrollMode(View.OVER_SCROLL_NEVER);
        webView.setLayerType(View.LAYER_TYPE_HARDWARE, null);
        setContentView(webView);
        // Android 15 enforces edge-to-edge for targetSdk 35; keep editor controls
        // inside safe system-bar and display-cutout insets.
        if (Build.VERSION.SDK_INT >= 35) {
            webView.setOnApplyWindowInsetsListener((view, insets) -> {
                android.graphics.Insets safe = insets.getInsets(
                        android.view.WindowInsets.Type.systemBars() | android.view.WindowInsets.Type.displayCutout());
                view.setPadding(safe.left, safe.top, safe.right, safe.bottom);
                return insets;
            });
            webView.requestApplyInsets();
        }

        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setMediaPlaybackRequiresUserGesture(false);
        settings.setAllowFileAccess(false);
        settings.setAllowContentAccess(true);
        settings.setSupportZoom(false);
        settings.setBuiltInZoomControls(false);
        settings.setDisplayZoomControls(false);
        settings.setLoadsImagesAutomatically(true);
        settings.setJavaScriptCanOpenWindowsAutomatically(false);
        settings.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        settings.setDefaultTextEncodingName("UTF-8");

        webView.addJavascriptInterface(new AndroidBridge(), "AndroidBridge");
        webView.setWebViewClient(new WebViewClient() {
            @Override
            public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                Uri u = request.getUrl();
                if (!"https".equalsIgnoreCase(u.getScheme()) || !HOST.equalsIgnoreCase(u.getHost())) {
                    return errorResponse(403, "Forbidden");
                }
                String path = u.getPath() == null ? "/" : u.getPath();
                if (path.startsWith("/media/")) {
                    String token = path.substring("/media/".length());
                    return streamMedia(token, request.getRequestHeaders());
                }
                if (path.startsWith("/assets/")) {
                    String asset = path.substring("/assets/".length());
                    try {
                        InputStream in = getAssets().open(asset);
                        Map<String, String> headers = new HashMap<>();
                        headers.put("Cache-Control", "no-cache");
                        headers.put("Access-Control-Allow-Origin", BASE_URL);
                        return new WebResourceResponse(mimeForName(asset), "UTF-8", 200, "OK", headers, in);
                    } catch (IOException e) {
                        return errorResponse(404, "Not Found");
                    }
                }
                return errorResponse(404, "Not Found");
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri u = request.getUrl();
                return !"https".equalsIgnoreCase(u.getScheme()) || !HOST.equalsIgnoreCase(u.getHost());
            }
        });
        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback, FileChooserParams params) {
                if (fileChooserCallback != null) fileChooserCallback.onReceiveValue(null);
                fileChooserCallback = callback;
                Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                intent.setType("*/*");
                intent.putExtra(Intent.EXTRA_MIME_TYPES, new String[]{
                        "model/gltf-binary", "application/octet-stream", "application/zip",
                        "video/*", "image/*", "audio/*"
                });
                intent.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, params.getMode() == FileChooserParams.MODE_OPEN_MULTIPLE);
                try {
                    startActivityForResult(intent, FILE_PICK_REQUEST);
                } catch (Exception e) {
                    fileChooserCallback = null;
                    callback.onReceiveValue(null);
                    Toast.makeText(MainActivity.this, "No file picker is available", Toast.LENGTH_SHORT).show();
                }
                return true;
            }
        });

        WebView.setWebContentsDebuggingEnabled(false);
        webView.loadUrl(BASE_URL + "/assets/index.html");
    }

    private static WebResourceResponse errorResponse(int code, String message) {
        return new WebResourceResponse("text/plain", "UTF-8", code, message,
                new HashMap<>(), new ByteArrayInputStream(message.getBytes(StandardCharsets.UTF_8)));
    }

    private String mimeForName(String name) {
        String lower = name.toLowerCase(Locale.ROOT);
        if (lower.endsWith(".html")) return "text/html";
        if (lower.endsWith(".js")) return "application/javascript";
        if (lower.endsWith(".css")) return "text/css";
        if (lower.endsWith(".json")) return "application/json";
        if (lower.endsWith(".svg")) return "image/svg+xml";
        if (lower.endsWith(".png")) return "image/png";
        if (lower.endsWith(".jpg") || lower.endsWith(".jpeg")) return "image/jpeg";
        return "application/octet-stream";
    }

    private WebResourceResponse streamMedia(String token, Map<String, String> requestHeaders) {
        Uri uri = mediaUris.get(token);
        if (uri == null) return errorResponse(404, "Media not registered");
        android.os.ParcelFileDescriptor pfd = null;
        try {
            pfd = getContentResolver().openFileDescriptor(uri, "r");
            if (pfd == null) return errorResponse(404, "Media unavailable");
            long length = pfd.getStatSize();
            String range = null;
            if (requestHeaders != null) {
                for (Map.Entry<String, String> h : requestHeaders.entrySet()) {
                    if ("range".equalsIgnoreCase(h.getKey())) { range = h.getValue(); break; }
                }
            }
            long start = 0, end = length > 0 ? length - 1 : -1;
            boolean partial = false;
            if (length > 0 && range != null) {
                Matcher matcher = Pattern.compile("bytes=(\\d*)-(\\d*)").matcher(range.trim());
                if (matcher.matches()) {
                    String a = matcher.group(1), b = matcher.group(2);
                    if (!a.isEmpty()) start = Long.parseLong(a);
                    if (!b.isEmpty()) end = Math.min(length - 1, Long.parseLong(b));
                    if (a.isEmpty() && !b.isEmpty()) {
                        long suffix = Long.parseLong(b);
                        start = Math.max(0, length - suffix);
                    }
                    if (start > end || start >= length) {
                        try { pfd.close(); } catch (Exception ignored) {}
                        return errorResponse(416, "Range Not Satisfiable");
                    }
                    partial = true;
                }
            }
            FileInputStream fileIn = new FileInputStream(pfd.getFileDescriptor());
            if (start > 0) fileIn.getChannel().position(start);
            final long remaining = length > 0 ? (end - start + 1) : -1;
            InputStream bounded = remaining >= 0 ? new LimitedInputStream(fileIn, remaining) : fileIn;
            String mime = getContentResolver().getType(uri);
            if (mime == null) mime = "application/octet-stream";
            Map<String, String> headers = new HashMap<>();
            headers.put("Accept-Ranges", "bytes");
            headers.put("Cache-Control", "no-store");
            headers.put("Access-Control-Allow-Origin", BASE_URL);
            headers.put("Access-Control-Allow-Headers", "Range");
            headers.put("Cross-Origin-Resource-Policy", "same-origin");
            if (remaining >= 0) headers.put("Content-Length", String.valueOf(remaining));
            if (partial) headers.put("Content-Range", "bytes " + start + "-" + end + "/" + length);
            final android.os.ParcelFileDescriptor closePfd = pfd;
            InputStream closing = new FilterInputStream(bounded) {
                @Override public void close() throws IOException {
                    try { super.close(); } finally { closePfd.close(); }
                }
            };
            return new WebResourceResponse(mime, null, partial ? 206 : 200,
                    partial ? "Partial Content" : "OK", headers, closing);
        } catch (Exception e) {
            try { if (pfd != null) pfd.close(); } catch (Exception ignored) {}
            return errorResponse(404, "Unable to read media");
        }
    }

    private static final class LimitedInputStream extends FilterInputStream {
        private long left;
        LimitedInputStream(InputStream input, long length) { super(input); left = length; }
        @Override public int read() throws IOException {
            if (left <= 0) return -1;
            int value = super.read(); if (value >= 0) left--; return value;
        }
        @Override public int read(byte[] b, int off, int len) throws IOException {
            if (left <= 0) return -1;
            int n = super.read(b, off, (int) Math.min(len, left)); if (n > 0) left -= n; return n;
        }
    }

    private void evaluate(String js) {
        if (webView != null) runOnUiThread(() -> {
            if (webView != null) webView.evaluateJavascript(js, null);
        });
    }

    // Open Android's system document/media picker for exactly one item. This avoids
    // enumerating the entire device library and works without broad media permissions.
    private void launchMediaPicker(String type, String mode) {
        pendingMediaType = type == null ? "video" : type;
        pendingMediaMode = mode == null ? "clip" : mode;
        Intent intent;
        // Android 13+ Photo Picker opens the native gallery-style video/photo
        // selector. It returns exactly one item by default and grants per-item
        // read access without asking for whole-library permissions.
        if (Build.VERSION.SDK_INT >= 33 && ("video".equals(pendingMediaType) || "image".equals(pendingMediaType))) {
            intent = new Intent(MediaStore.ACTION_PICK_IMAGES);
            intent.setType("video".equals(pendingMediaType) ? "video/*" : "image/*");
            intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        } else {
            intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
            intent.addCategory(Intent.CATEGORY_OPENABLE);
            intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
            intent.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, false);
            if ("video".equals(pendingMediaType)) {
                intent.setType("video/*");
            } else if ("image".equals(pendingMediaType)) {
                intent.setType("image/*");
            } else if ("audio".equals(pendingMediaType)) {
                intent.setType("audio/*");
            } else if ("model".equals(pendingMediaType)) {
                intent.setType("*/*");
                intent.putExtra(Intent.EXTRA_MIME_TYPES, new String[]{"model/gltf-binary", "application/octet-stream"});
            } else {
                intent.setType("*/*");
            }
        }
        try {
            startActivityForResult(intent, PICK_MEDIA_REQUEST);
        } catch (Exception e) {
            evaluate("window.onNativePickError && window.onNativePickError(" + JSONObject.quote(e.getMessage() == null ? "No Android file picker is available" : e.getMessage()) + ");");
        }
    }

    private JSONObject pickedMediaPayload(Uri uri) throws Exception {
        String token = "pick_" + UUID.randomUUID().toString().replace("-", "");
        mediaUris.put(token, uri);
        reverseMediaIds.put(uri.toString(), token);
        String name = "Selected media";
        long sizeBytes = 0;
        try (Cursor c = getContentResolver().query(uri, new String[]{android.provider.OpenableColumns.DISPLAY_NAME, android.provider.OpenableColumns.SIZE}, null, null, null)) {
            if (c != null && c.moveToFirst()) {
                int col = c.getColumnIndex(android.provider.OpenableColumns.DISPLAY_NAME);
                if (col >= 0 && !c.isNull(col)) name = c.getString(col);
                int sizeCol = c.getColumnIndex(android.provider.OpenableColumns.SIZE);
                if (sizeCol >= 0 && !c.isNull(sizeCol)) sizeBytes = c.getLong(sizeCol);
            }
        } catch (Exception ignored) {}
        // Some document providers do not expose OpenableColumns.SIZE.
        if (sizeBytes <= 0) {
            try (android.os.ParcelFileDescriptor fd = getContentResolver().openFileDescriptor(uri, "r")) {
                if (fd != null && fd.getStatSize() > 0) sizeBytes = fd.getStatSize();
            } catch (Exception ignored) {}
        }
        String mime = getContentResolver().getType(uri);
        if (mime == null) {
            mime = "video".equals(pendingMediaType) ? "video/*" :
                    "image".equals(pendingMediaType) ? "image/*" :
                    "audio".equals(pendingMediaType) ? "audio/*" : "model/gltf-binary";
        }
        JSONObject item = new JSONObject();
        item.put("id", token);
        item.put("appId", "device_" + token);
        item.put("type", pendingMediaType);
        item.put("mode", pendingMediaMode);
        item.put("name", name);
        item.put("mime", mime);
        item.put("sizeBytes", sizeBytes);
        item.put("uri", uri.toString());
        item.put("url", BASE_URL + "/media/" + token);
        item.put("duration", 0);
        item.put("width", 0);
        item.put("height", 0);
        return item;
    }

    private Uri registerMediaUri(String raw) {
        if (raw == null || raw.trim().isEmpty()) return null;
        try {
            Uri uri = Uri.parse(raw);
            if (!"content".equals(uri.getScheme()) || uri.getAuthority() == null) return null;
            String existing = reverseMediaIds.get(raw);
            if (existing != null) return mediaUris.get(existing) == null ? uri : mediaUris.get(existing);
            String token = "p_" + UUID.randomUUID().toString().replace("-", "");
            mediaUris.put(token, uri); reverseMediaIds.put(raw, token);
            return uri;
        } catch (Exception e) { return null; }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == PICK_MEDIA_REQUEST) {
            if (resultCode == RESULT_OK && data != null && data.getData() != null) {
                Uri uri = data.getData();
                try {
                    final int flags = data.getFlags() & (Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
                    try { getContentResolver().takePersistableUriPermission(uri, flags == 0 ? Intent.FLAG_GRANT_READ_URI_PERMISSION : flags); }
                    catch (Exception ignored) { /* Some providers grant transient read access only. */ }
                    JSONObject item = pickedMediaPayload(uri);
                    evaluate("window.onNativePickedMedia && window.onNativePickedMedia(" + item.toString() + ");");
                } catch (Exception e) {
                    String token = reverseMediaIds.remove(uri.toString());
                    if (token != null) mediaUris.remove(token);
                    evaluate("window.onNativePickError && window.onNativePickError(" + JSONObject.quote(e.getMessage() == null ? "Could not open selected media" : e.getMessage()) + ");");
                }
            } else {
                evaluate("window.onNativePickCanceled && window.onNativePickCanceled();");
            }
            return;
        }
        if (requestCode == FILE_PICK_REQUEST && fileChooserCallback != null) {
            Uri[] results = null;
            if (resultCode == RESULT_OK && data != null) {
                if (data.getClipData() != null) {
                    int count = data.getClipData().getItemCount(); results = new Uri[count];
                    for (int i = 0; i < count; i++) results[i] = data.getClipData().getItemAt(i).getUri();
                } else if (data.getData() != null) results = new Uri[]{data.getData()};
            }
            fileChooserCallback.onReceiveValue(results); fileChooserCallback = null;
        }
    }

    public class AndroidBridge {
        @JavascriptInterface
        public void pickMedia(String type, String mode) {
            runOnUiThread(() -> launchMediaPicker(type, mode));
        }

        @JavascriptInterface
        public void showMediaLibrary() {
            runOnUiThread(() -> launchMediaPicker("video", "clip"));
        }

        @JavascriptInterface
        public void releaseMediaUri(String rawUri) {
            if (rawUri == null) return;
            String token = reverseMediaIds.remove(rawUri);
            if (token != null) mediaUris.remove(token);
        }

        @JavascriptInterface
        public String getMediaUrl(String rawUri) {
            Uri uri = registerMediaUri(rawUri); if (uri == null) return "";
            String token = reverseMediaIds.get(rawUri);
            if (token == null) {
                for (Map.Entry<String, Uri> e : mediaUris.entrySet()) if (e.getValue().equals(uri)) { token = e.getKey(); break; }
            }
            return token == null ? "" : BASE_URL + "/media/" + token;
        }

        @JavascriptInterface
        public void openAppSettings() {
            runOnUiThread(() -> {
                Intent intent = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + getPackageName()));
                startActivity(intent);
            });
        }

        @JavascriptInterface
        public void setKeepScreenOn(boolean keep) {
            runOnUiThread(() -> {
                if (keep) getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
                else getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
            });
        }

        @JavascriptInterface
        public boolean beginExport(String fileName, String mimeType) {
            synchronized (exportLock) {
                try {
                    closeExport(false);
                    String safe = fileName == null ? "PixelCut-Export" : fileName.replaceAll("[\\\\/:*?\"<>|]", "_");
                    if (safe.isEmpty()) safe = "PixelCut-Export";
                    String mime = mimeType == null ? "application/octet-stream" : mimeType;
                    exportName = safe;
                    if (Build.VERSION.SDK_INT >= 29) {
                        boolean video = mime.startsWith("video/");
                        Uri collection = video ? MediaStore.Video.Media.EXTERNAL_CONTENT_URI : MediaStore.Downloads.EXTERNAL_CONTENT_URI;
                        ContentValues values = new ContentValues();
                        values.put(MediaStore.MediaColumns.DISPLAY_NAME, safe);
                        values.put(MediaStore.MediaColumns.MIME_TYPE, mime);
                        values.put(MediaStore.MediaColumns.RELATIVE_PATH, video ? Environment.DIRECTORY_MOVIES + "/PixelCut Aero" : Environment.DIRECTORY_DOWNLOADS + "/PixelCut Aero Projects");
                        values.put(MediaStore.MediaColumns.IS_PENDING, 1);
                        exportUri = getContentResolver().insert(collection, values);
                        if (exportUri == null) return false;
                        exportStream = getContentResolver().openOutputStream(exportUri, "w");
                    } else {
                        File base = getExternalFilesDir(mime.startsWith("video/") ? Environment.DIRECTORY_MOVIES : Environment.DIRECTORY_DOCUMENTS);
                        File dir = new File(base, "PixelCut Aero");
                        if (!dir.exists() && !dir.mkdirs()) return false;
                        legacyExportFile = new File(dir, safe);
                        exportStream = new FileOutputStream(legacyExportFile);
                    }
                    return exportStream != null;
                } catch (Exception e) {
                    android.util.Log.e("PixelCutAero", "beginExport", e); closeExport(false); return false;
                }
            }
        }

        @JavascriptInterface
        public boolean writeExportChunk(String base64) {
            synchronized (exportLock) {
                try {
                    if (exportStream == null || base64 == null) return false;
                    byte[] data = Base64.decode(base64, Base64.DEFAULT);
                    exportStream.write(data);
                    return true;
                } catch (Exception e) { android.util.Log.e("PixelCutAero", "writeExportChunk", e); return false; }
            }
        }

        @JavascriptInterface
        public boolean finishExport() {
            synchronized (exportLock) {
                try { closeExport(true); return true; }
                catch (Exception e) { android.util.Log.e("PixelCutAero", "finishExport", e); closeExport(false); return false; }
            }
        }

        @JavascriptInterface
        public void abortExport() { synchronized (exportLock) { closeExport(false); } }
    }

    private void closeExport(boolean publish) {
        try { if (exportStream != null) { exportStream.flush(); exportStream.close(); } } catch (Exception ignored) {}
        exportStream = null;
        if (Build.VERSION.SDK_INT >= 29 && exportUri != null) {
            try {
                if (publish) {
                    ContentValues values = new ContentValues(); values.put(MediaStore.MediaColumns.IS_PENDING, 0);
                    getContentResolver().update(exportUri, values, null, null);
                } else getContentResolver().delete(exportUri, null, null);
            } catch (Exception e) { android.util.Log.e("PixelCutAero", "publish export", e); }
        } else if (legacyExportFile != null && !publish) {
            try { legacyExportFile.delete(); } catch (Exception ignored) {}
        } else if (legacyExportFile != null && publish) {
            final String path = legacyExportFile.getAbsolutePath();
            runOnUiThread(() -> Toast.makeText(this, "Export saved: " + path, Toast.LENGTH_LONG).show());
        }
        exportUri = null; legacyExportFile = null;
        if (publish && exportName != null) {
            final String saved = exportName;
            runOnUiThread(() -> evaluate("window.onNativeExportSaved && window.onNativeExportSaved(" + JSONObject.quote(saved) + ");"));
        }
        exportName = null;
    }

    @Override
    public void onTrimMemory(int level) {
        super.onTrimMemory(level);
        if (level >= TRIM_MEMORY_RUNNING_LOW && webView != null) {
            evaluate("window.releaseEditorResources && window.releaseEditorResources();");
        }
    }

    @Override
    public void onLowMemory() {
        super.onLowMemory();
        if (webView != null) evaluate("window.releaseEditorResources && window.releaseEditorResources();");
    }

    @Override
    protected void onPause() {
        if (webView != null) {
            webView.evaluateJavascript("try{if(window.AndroidBridge){AndroidBridge.setKeepScreenOn(false)};if(typeof saveP==='function')saveP();if(typeof releaseEditorResources==='function')releaseEditorResources();else if(typeof stop==='function')stop();}catch(e){}", null);
            webView.onPause();
        }
        getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        super.onPause();
    }

    @Override
    protected void onResume() { super.onResume(); if (webView != null) webView.onResume(); }

    @Override
    public void onBackPressed() {
        if (webView == null) { super.onBackPressed(); return; }
        webView.evaluateJavascript("String(window.androidBack ? window.androidBack() : false)", value -> {
            if ("false".equals(value)) MainActivity.super.onBackPressed();
        });
    }

    @Override
    protected void onDestroy() {
        synchronized (exportLock) { closeExport(false); }
        if (fileChooserCallback != null) { try { fileChooserCallback.onReceiveValue(null); } catch (Exception ignored) {} fileChooserCallback = null; }
        if (webView != null) {
            try { webView.stopLoading(); webView.onPause(); webView.removeJavascriptInterface("AndroidBridge"); webView.clearHistory(); webView.removeAllViews(); webView.destroy(); }
            catch (Exception e) { android.util.Log.w("PixelCutAero", "WebView cleanup", e); }
            webView = null;
        }
        mediaUris.clear();
        reverseMediaIds.clear();
        super.onDestroy();
    }
}
