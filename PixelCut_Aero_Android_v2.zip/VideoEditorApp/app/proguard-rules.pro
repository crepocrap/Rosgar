# The app uses a JavaScript bridge whose methods are annotated with @JavascriptInterface.
# Keep bridge members if minification is enabled in a future release.
-keepclassmembers class com.pixelcutaero.editor.MainActivity$AndroidBridge {
    @android.webkit.JavascriptInterface <methods>;
}
